# Widget Ebit

Storefront plugin for Ebit to order avaliation
